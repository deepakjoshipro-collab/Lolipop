import "dotenv/config";
import { 
  Client, 
  GatewayIntentBits, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  StringSelectMenuBuilder 
} from "discord.js";
import axios from "axios";
import fs from "fs";
import QRCode from "qrcode";
import emojis from "./emoji.json" assert { type: "json" }; // <-- EMOJI FILE IMPORTED

// ===== CONFIG =====
const TOKEN = process.env.DISCORD_TOKEN;
const WATCH_ADDRESS = process.env.WATCH_ADDRESS;
const PREFIX = process.env.PREFIX || ",";

// --- NEW EXCHANGE RATES ---
const I2C_RATE = 94.5;
const C2I_RATE = 90.5;

// The single owner who will receive DM notifications and can use admin commands
const NOTIFICATION_OWNER_ID = "925424598680481873";

// This allows the owner and other specified users to use commands without the prefix
const OWNERS = [NOTIFICATION_OWNER_ID]; 

const CHECK_INTERVAL = 20000; // 20s

const BC_KEYS = [
  process.env.BC_KEY1,
  process.env.BC_KEY2,
  process.env.BC_KEY3,
  process.env.BC_KEY4,
  process.env.BC_KEY5,
  process.env.BC_KEY6,
].filter(Boolean);

let keyIndex = 0;
function getApiKey() {
  keyIndex = (keyIndex + 1) % BC_KEYS.length;
  return BC_KEYS[keyIndex];
}

// ===== STATE =====
const LAST_SEEN_FILE = "last_seen.json";
let lastSeen = {};
if (fs.existsSync(LAST_SEEN_FILE)) {
  try {
    lastSeen = JSON.parse(fs.readFileSync(LAST_SEEN_FILE));
  } catch {
    lastSeen = {};
  }
}
function saveLastSeen() {
  fs.writeFileSync(LAST_SEEN_FILE, JSON.stringify(lastSeen, null, 2));
}

// --- No Prefix Users ---
let noPrefixUsers = [];
const NO_PREFIX_FILE = "no_prefix_users.json";
if (fs.existsSync(NO_PREFIX_FILE)) {
  try {
    noPrefixUsers = JSON.parse(fs.readFileSync(NO_PREFIX_FILE));
  } catch {
    noPrefixUsers = [];
  }
}
function saveNoPrefixUsers() {
  fs.writeFileSync(NO_PREFIX_FILE, JSON.stringify(noPrefixUsers, null, 2));
}

// ===== HELPERS =====

// Helper to get just the ID from the emoji string for components
function getEmojiId(emojiString) {
  const match = emojiString.match(/<a?:\w+:(\d+)>$/);
  return match ? match[1] : emojiString;
}

async function getLatestTx(address) {
  const url = `https://api.blockcypher.com/v1/ltc/main/addrs/${address}/full?limit=1&token=${getApiKey()}`;
  try {
    const res = await axios.get(url, { timeout: 10000 });
    if (res.data.txs && res.data.txs.length > 0) return res.data.txs[0];
  } catch {
    return null;
  }
  return null;
}

async function getUsdPrice() {
  try {
    const res = await axios.get(
      "https://api.coingecko.com/api/v3/simple/price",
      {
        params: { ids: "litecoin", vs_currencies: "usd" },
        timeout: 5000,
      }
    );
    return res.data.litecoin.usd;
  } catch {
    return 0;
  }
}

function computeFlow(tx, addr) {
  let inSats = 0;
  for (const inp of tx.inputs || []) {
    if ((inp.addresses || []).includes(addr)) {
      inSats += parseInt(inp.output_value || 0);
    }
  }

  let outSats = 0;
  for (const outp of tx.outputs || []) {
    if ((outp.addresses || []).includes(addr)) {
      outSats += parseInt(outp.value || 0);
    }
  }

  const net = outSats - inSats;
  if (net > 0) return ["Received", net];
  if (net < 0) return ["Sent", -net];
  return ["Self-transfer", 0];
}

function buildEmbed(txid, direction, ltcAmount, usdAmount, status, timeStr, bot, confirmed) {
  const color = confirmed ? 0x92e0ac :0xff665b ;
  const embed = new EmbedBuilder().setColor(color);

  embed.addFields(
    { name: "__Amount__", value: `${ltcAmount.toFixed(8)} LTC (~$${usdAmount})`, inline: true },
    { name: "__Sent When__", value: timeStr, inline: true },
    { name: "__Address__", value: WATCH_ADDRESS, inline: false },
    { name: "__Transaction ID__", value: `[View TX](https://live.blockcypher.com/ltc/tx/${txid})`, inline: false }
  );

  embed.setThumbnail("https://cryptologos.cc/logos/litecoin-ltc-logo.png");
  embed.setFooter({
    // --- TIMESTAMP CHANGED TO IST ---
    text: `Powered by ${bot.user.username} • ${new Date().toLocaleString("en-GB", { timeZone: "Asia/Kolkata" })} IST`,
    iconURL: bot.user.displayAvatarURL(),
  });

  return embed;
}

function logTransaction(txid, direction, ltcAmount, usdAmount, status, timeStr) {
  const logLine = `[${new Date().toISOString()}] ${direction} ${ltcAmount.toFixed(8)} LTC (~$${usdAmount}) | ${status} | TX: ${txid} | Time: ${timeStr}\n`;
  fs.appendFileSync("transactions.log", logLine);
}

// ===== BOT =====
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds, 
    GatewayIntentBits.GuildMessages, 
    GatewayIntentBits.MessageContent, 
    GatewayIntentBits.DirectMessages
  ],
  partials: ["CHANNEL"],
});

client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);

  setInterval(async () => {
    const tx = await getLatestTx(WATCH_ADDRESS);
    if (!tx) return;

    const txid = tx.hash;
    const confirmations = tx.confirmations || 0;
    const confirmed = confirmations > 0;

    if (lastSeen[txid] === confirmed) return;
    lastSeen[txid] = confirmed;
    saveLastSeen();

    const [direction, amountSats] = computeFlow(tx, WATCH_ADDRESS);
    const ltcAmount = amountSats / 1e8;
    const usdAmount = (ltcAmount * (await getUsdPrice())).toFixed(2);
    const status = confirmed ? "✅ Confirmed" : "⏳ Pending";

    let unixTs = "Unknown";
    try {
      unixTs = `<t:${Math.floor(new Date(tx.received).getTime() / 1000)}:R>`;
    } catch {}

    const embed = buildEmbed(txid, direction, ltcAmount, usdAmount, status, unixTs, client, confirmed);

    try {
      const owner = await client.users.fetch(NOTIFICATION_OWNER_ID);
      const messageContent = confirmed
        ? `**<@${NOTIFICATION_OWNER_ID}> ${direction} $${usdAmount} Successfully!**`
        : `**<@${NOTIFICATION_OWNER_ID}> ${direction} $${usdAmount}, In Process!**`;
      
      await owner.send({ content: messageContent, embeds: [embed] });

      logTransaction(txid, direction, ltcAmount, usdAmount, status, unixTs);
      console.log(`[+] Sent TX ${txid} notification to ${owner.tag}`);
    } catch (e) {
      console.error(`[!] Could not DM owner ${NOTIFICATION_OWNER_ID}.`, e);
    }
  }, CHECK_INTERVAL);
});

// --- Data persistence ---
let addresses = {};
if (fs.existsSync("addresses.json")) addresses = JSON.parse(fs.readFileSync("addresses.json"));
function saveAddresses() {
  fs.writeFileSync("addresses.json", JSON.stringify(addresses, null, 2));
}

let upiAddresses = {};
if (fs.existsSync("upi.json")) upiAddresses = JSON.parse(fs.readFileSync("upi.json"));
function saveUpi() {
  fs.writeFileSync("upi.json", JSON.stringify(upiAddresses, null, 2));
}

// --- API Fetchers ---
async function getLtcData() {
  try {
    const res = await axios.get("https://api.coingecko.com/api/v3/simple/price", {
      params: { ids: "litecoin", vs_currencies: "usd", include_24hr_change: "true" }
    });
    return res.data.litecoin;
  } catch { return null; }
}

async function getDetailedBalance(address) {
  try {
    const res = await axios.get(`https://api.blockcypher.com/v1/ltc/main/addrs/${address}/balance`);
    return {
      confirmed: res.data.balance / 1e8,
      unconfirmed: res.data.unconfirmed_balance / 1e8,
      total: res.data.final_balance / 1e8
    };
  } catch { return null; }
}

// --- UPDATED QR HELPER ---
/**
 * Builds the UPI selection embed and components.
 * @param {object} userUpis - The user's UPI object from upiAddresses.
 * @param {string} amountString - The amount as a string, or '0' if no amount.
 * @returns {object} - An object containing { embeds: [embed], components: components }
 */
function buildUpiSelection(userUpis, amountString) {
  const embed = new EmbedBuilder()
    .setTitle("UPI Payment")
    .setColor(0x8B0000); // Dark color from screenshot

  const amountText = (amountString && amountString !== '0' && !isNaN(amountString)) 
    ? `₹${amountString}` 
    : 'No amount specified';
    
  let description = `\`\`\`\nAmount: ${amountText}\nSelect a UPI ID to generate QR code\n\`\`\``;
  embed.setDescription(description);
  
  const components = [];
  let currentRow = new ActionRowBuilder();
  let counter = 1;
  const fields = []; 

  for (const [upiName, upiId] of Object.entries(userUpis)) {
    
    fields.push({
        name: `${emojis.star_white_motion} UPI #${counter}`, // <-- EMOJI
        value: upiId,
        inline: false 
    });

    const button = new ButtonBuilder()
      .setCustomId(`gen_qr_${upiName}_${amountString || '0'}`)
      .setLabel(`Generate QR #${counter}`)
      .setStyle(ButtonStyle.Primary)
      .setEmoji(getEmojiId(emojis.qr_code)); // <-- EMOJI
    
    if (currentRow.components.length >= 5) {
      components.push(currentRow);
      currentRow = new ActionRowBuilder();
    }
    currentRow.addComponents(button);
    counter++;
  }
  if (currentRow.components.length > 0) {
     components.push(currentRow); // Add the last row
  }

  if (fields.length > 0) {
      embed.addFields(fields); 
  }
  
  return { embeds: [embed], components: components, files: [] }; // Ensure files is empty
}


// ===== NEW: HELP COMMAND DATA (WITH COOLER EMOJIS) =====
const commandsInfo = {
  setaddy: {
    usage: "`,setaddy <address>`",
    description: "Saves your personal Litecoin (LTC) address to the bot. This allows you to use the `,mybal` command without typing your address every time.",
    emoji: emojis.backup, // <-- REPLACED
  },
  addy: {
    usage: "`,addy`",
    description: "Displays your saved LTC address in a private message only visible to you. This uses the address you set with `,setaddy`.",
    emoji: emojis.nitro_heart, // <-- REPLACED
  },
  mybal: {
    usage: "`,mybal`",
    description: "Shows the confirmed, unconfirmed, and total balance of your saved LTC address. You must use `,setaddy` first.",
    emoji: emojis.paisaa, // <-- REPLACED
  },
  bal: {
    usage: "`,bal <address>`",
    description: "Checks the confirmed, unconfirmed, and total balance of *any* specified LTC address.",
    emoji: emojis.calculator_total, // <-- REPLACED
  },
  ltc: {
    usage: "`,ltc`",
    description: "Shows the current price of Litecoin (LTC) in USD and its 24-hour percentage change.",
    emoji: emojis.stocks, // <-- KEPT (Good)
  },
  setupi: {
    usage: "`,setupi <name> <upi>`",
    description: "Saves a UPI ID with a custom name (e.g., `,setupi main 123@upi`). You can save multiple UPI IDs with different names.",
    emoji: emojis.settings, // <-- REPLACED
  },
  upi: {
    usage: "`,upi`",
    description: "Displays all of your saved UPI IDs and their names in a private message only visible to you.",
    emoji: emojis.star_animated, // <-- REPLACED
  },
  removeupi: {
    usage: "`,removeupi <name>`",
    description: "Removes a *specific* UPI ID that you saved using its name (e.g., `,removeupi main`).",
    emoji: emojis.delete_bin, // <-- KEPT (Good)
  },
  clearupi: {
    usage: "`,clearupi`",
    description: "Removes *all* of your saved UPI IDs at once.",
    emoji: emojis.success, // <-- KEPT (Good)
  },
  qr: {
    usage: "`,qr <amount>`",
    description: "Generates a UPI QR code. If you provide an amount (e.g., `,qr 100`), the QR code will be pre-filled with that amount. If you have multiple UPIs, it will ask you to select one.",
    emoji: emojis.qr_code, // <-- REPLACED
  },
  i2c: {
    usage: "`,i2c <amount>` or `,i2c <amount>$`",
    description: "Calculates an INR to Crypto (I2C) conversion. \nExample 1: `,i2c 945` (calculates $ from INR) \nExample 2: `,i2c 10$` (calculates INR from $)",
    emoji: emojis.exchange, // <-- KEPT (Good)
  },
  c2i: {
    usage: "`,c2i <amount>` or `,c2i <amount>$`",
    description: "Calculates a Crypto to INR (C2I) conversion. \nExample 1: `,c2i 905` (calculates $ from INR) \nExample 2: `,c2i 10$` (calculates INR from $)",
    emoji: emojis.dollars, // <-- KEPT (Good)
  },
  np: {
    usage: "`,np <add|remove|list> <user>`",
    description: "Owner Only. Manages users who can use commands without the prefix.",
    emoji: emojis.pepe_finger, // <-- KEPT (Good)
  },
};
// ===== END: HELP COMMAND DATA =====


// --- MESSAGE HANDLER ---
client.on("messageCreate", async (msg) => {
  if (msg.author.bot) return;

  let command, args;
  const isNoPrefixUser = OWNERS.includes(msg.author.id) || noPrefixUsers.includes(msg.author.id);

  if (msg.content.startsWith(PREFIX)) {
    [command, ...args] = msg.content.slice(PREFIX.length).trim().split(/ +/);
  } else if (isNoPrefixUser) {
    [command, ...args] = msg.content.trim().split(/ +/);
  } else return;
  
  if (command) command = command.toLowerCase();

  // --- NP Commands (Owner only) ---
  if (command === "np") {
    if (msg.author.id !== NOTIFICATION_OWNER_ID) return msg.reply(`${emojis.pepe_finger}   You don't have permission for this command.`);
    const subCommand = args[0]?.toLowerCase();
    const targetUserId = args[1]?.replace(/[<@!>]/g, '');

    if (subCommand === "add") {
      if (!targetUserId) return msg.reply(`${emojis.invalid_alert} Usage: \`,np add @user\` or \`,np add USER_ID\``);
      if (noPrefixUsers.includes(targetUserId)) return msg.reply(`${emojis.invalid_alert} That user is already on the no-prefix list.`);
      noPrefixUsers.push(targetUserId);
      saveNoPrefixUsers();
      return msg.reply(`${emojis.success}  Added <@${targetUserId}> to the no-prefix list.`);
    }

    if (subCommand === "remove") {
      if (!targetUserId) return msg.reply(`${emojis.invalid_alert} Usage: \`,np remove @user\` or \`,np remove USER_ID\``);
      const index = noPrefixUsers.indexOf(targetUserId);
      if (index === -1) return msg.reply(`${emojis.invalid_alert} That user is not on the no-prefix list.`);
      noPrefixUsers.splice(index, 1);
      saveNoPrefixUsers();
      return msg.reply(`${emojis.success}  Removed <@${targetUserId}> from the no-prefix list.`);
    }

    if (subCommand === "list") {
      if (noPrefixUsers.length === 0) return msg.reply(`${emojis.invalid_alert} The no-prefix list is empty.`);
      const userList = noPrefixUsers.map(id => `- <@${id}> (${id})`).join("\n");
      const embed = new EmbedBuilder().setTitle(`${emojis.pepe_finger}   Users With No-Prefix Access`).setDescription(userList).setColor(0x7289da);
      return msg.reply({ embeds: [embed] });
    }

    return msg.reply(`${emojis.invalid_alert} Invalid command. Use \`,np add\`, \`,np remove\`, or \`,np list\`.\n`);
  }
  
  // --- NEW HELP Command (COOLER EMBED) ---
  if (command === "help") {
    const embed = new EmbedBuilder()
      .setTitle(`${emojis.glow_star} Bot Commands ${emojis.glow_star}`) // <-- EMOJI
      .setColor(0x731b15)
      .setDescription(`Welcome! Select a command from the dropdown menu to see its details, usage, and description.\n\n${emojis.settings} Powered by ${client.user.username}`) // <-- EMOJI
      .setFooter({ text: "Use these commands with prefix ','" });

    // Create options for the select menu from our commandsInfo object
    const options = Object.keys(commandsInfo).map(cmdKey => {
      const cmd = commandsInfo[cmdKey];
      
      let label = cmd.usage.split(' ')[0]; 
      if (cmdKey === 'np') label = ',np';
      
      let description = cmd.description.split('.')[0]; 

      return {
        label: label,
        description: description,
        value: cmdKey, // e.g., "setaddy"
        emoji: getEmojiId(cmd.emoji), // <-- EMOJI (ID only)
      };
    });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId("help_menu")
      .setPlaceholder("Choose a command...")
      .addOptions(options);

    const row = new ActionRowBuilder().addComponents(selectMenu);

    return msg.reply({ embeds: [embed], components: [row] });
  }

  // --- Set address ---
  if (command === "setaddy") {
    const addr = args[0];
    if (!addr) return msg.reply(`${emojis.invalid_alert} Provide an LTC address.`);
    addresses[msg.author.id] = addr;
    saveAddresses();
    return msg.reply(`${emojis.ok_done} Your LTC address has been saved.`); // <-- EMOJI
  }

  // --- Show address ---
  if (command === "addy") {
    const addr = addresses[msg.author.id];
    if (!addr) return msg.reply(`${emojis.invalid_alert} You haven't set an address.`);
    const embed = new EmbedBuilder().setTitle(`${emojis.nitro_heart} Saved LTC Address`).setDescription("Click the button below to reveal it.").setColor(0x7289da); // <-- EMOJI
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("showaddy").setLabel("Show Address").setStyle(ButtonStyle.Primary));
    return msg.reply({ embeds: [embed], components: [row] });
  }

  // --- My balance ---
  if (command === "mybal") {
    const addr = addresses[msg.author.id];
    if (!addr) return msg.reply(`${emojis.invalid_alert} You haven't set an address yet.`);
    const [bal, ltc] = await Promise.all([getDetailedBalance(addr), getLtcData()]);
    if (!bal || !ltc) return msg.reply(`${emojis.invalid_alert} Failed to fetch data.`);
    
    const embed = new EmbedBuilder().setColor(0x621712).setTitle("LTC ADDRESS BALANCE").addFields(
      { name: `${emojis.done} Confirmed`, value: `${bal.confirmed} LTC (~$${(bal.confirmed * ltc.usd).toFixed(2)})` },
      { name: `${emojis.time_loading} Unconfirmed`, value: `${bal.unconfirmed} LTC (~$${(bal.unconfirmed * ltc.usd).toFixed(2)})` }, // <-- EMOJI
      { name: `${emojis.calculator_total} Total`, value: `${bal.total} LTC (~$${(bal.total * ltc.usd).toFixed(2)})` } // <-- EMOJI
    )
    // --- TIMESTAMP CHANGED TO IST ---
    .setFooter({ text: `${client.user.username} • ${new Date().toLocaleString("en-GB", { timeZone: "Asia/Kolkata" })} IST`, iconURL: client.user.displayAvatarURL({ dynamic: true }) });
    return msg.reply({ embeds: [embed] });
  }

  // --- Any address balance ---
  if (command === "bal") {
    const addr = args[0];
    if (!addr) return msg.reply(`${emojis.invalid_alert} Provide an LTC address.`);
    const [bal, ltc] = await Promise.all([getDetailedBalance(addr), getLtcData()]);
    if (!bal || !ltc) return msg.reply(`${emojis.invalid_alert} Failed to fetch data.`);

    const embed = new EmbedBuilder().setTitle(`${emojis.calculator_total} LTC Address Balance`).setColor(0xe67e22).addFields( // <-- EMOJI
      { name: `${emojis.ltc} Confirmed`, value: `${bal.confirmed} LTC (~$${(bal.confirmed * ltc.usd).toFixed(2)})` },
      { name: `${emojis.time_loading} Unconfirmed`, value: `${bal.unconfirmed} LTC (~$${(bal.unconfirmed * ltc.usd).toFixed(2)})` }, // <-- EMOJI
      { name: `${emojis.paisaa} Total`, value: `${bal.total} LTC (~$${(bal.total * ltc.usd).toFixed(2)})` } // <-- EMOJI
    );
    return msg.reply({ embeds: [embed] });
  }

  // --- LTC price ---
  if (command === "ltc") {
    const ltc = await getLtcData();
    if (!ltc) return msg.reply(`${emojis.invalid_alert} Failed to fetch price.`);
    const arrow = ltc.usd_24h_change >= 0 ? emojis.green_up : emojis.down_red;
    const embed = new EmbedBuilder().setTitle(`${emojis.stocks} LTC Price`).setColor(ltc.usd_24h_change >= 0 ? 0x2ecc71 : 0xe74c3c)
      .setDescription(`1 LTC = ${emojis.money} **$${ltc.usd.toFixed(2)}**\n${arrow} 24h: ${ltc.usd_24h_change.toFixed(2)}%`); // <-- EMOJI
    return msg.reply({ embeds: [embed] });
  }

  // --- UPI Commands ---
  if (command === "setupi") {
    const [name, upi] = args;
    if (!name || !upi) return msg.reply(`${emojis.invalid_alert} Use: \`,setupi <name> <upi_id>\``);
    if (!upiAddresses[msg.author.id]) upiAddresses[msg.author.id] = {};
    upiAddresses[msg.author.id][name] = upi;
    saveUpi();
    return msg.reply(`${emojis.ok_done} Saved UPI '${name}'${name === "default" ? emojis.star_maroon : ""}`); // <-- EMOJIS
  }

  if (command === "upi") {
    const userUpis = upiAddresses[msg.author.id];
    if (!userUpis || Object.keys(userUpis).length === 0) return msg.reply(`${emojis.invalid_alert} No UPI IDs saved.`);
    const embed = new EmbedBuilder().setTitle(`${emojis.star_animated} Saved UPI Wallets`).setDescription("Click below to reveal your UPI IDs.").setColor(0x5865f2); // <-- EMOJI
    if (userUpis.default) embed.setFooter({ text: ` ${emojis.star_maroon} Default: ${userUpis.default}` }); // <-- EMOJI
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("showupi").setLabel("Show UPI IDs").setStyle(ButtonStyle.Success));
    return msg.reply({ embeds: [embed], components: [row] });
  }
  
  // --- NEW: REMOVE UPI COMMAND ---
  if (command === "removeupi") {
      const name = args[0];
      if (!name) return msg.reply(`${emojis.invalid_alert} Use: \`,removeupi <name>\``);
      
      const userUpis = upiAddresses[msg.author.id];
      if (!userUpis || !userUpis[name]) {
          return msg.reply(`${emojis.invalid_alert} No UPI ID found with the name '${name}'.`);
      }
      
      delete userUpis[name];
      saveUpi();
      return msg.reply(`${emojis.delete_bin}  Successfully removed UPI ID '${name}'.`);
  }

  // --- NEW: CLEAR UPI COMMAND ---
  if (command === "clearupi") {
      const userUpis = upiAddresses[msg.author.id];
      if (!userUpis || Object.keys(userUpis).length === 0) {
          return msg.reply(`${emojis.invalid_alert} You have no UPI IDs saved to clear.`);
      }
      
      upiAddresses[msg.author.id] = {};
      saveUpi();
      return msg.reply(`${emojis.success}  Successfully cleared all your saved UPI IDs.`);
  }

  // --- NEW QR COMMAND ---
  if (command === "qr") {
    const amount = args[0]; // Can be undefined
    const userUpis = upiAddresses[msg.author.id];

    if (!userUpis || Object.keys(userUpis).length === 0) {
      return msg.reply(`${emojis.invalid_alert} No UPI IDs saved. Set a UPI ID first using \`,setupi <name> <upi_id>\`.`);
    }
    
    const amountString = (amount && !isNaN(amount)) ? amount : '0';
    const selectionPayload = buildUpiSelection(userUpis, amountString);
    return msg.reply(selectionPayload);
  }

  // ===== NEW I2C COMMAND =====
  if (command === "i2c") {
    const input = args[0];

    // --- ERROR EMOJI: Not changing this error embed per user request ---
    if (!input) {
      const errEmbed = new EmbedBuilder().setColor(0xe74c3c).setTitle("❌ Missing Amount")
        .setDescription("Please provide an amount.\n**Usage:**\n`,i2c <amount>` (e.g. `,i2c 945`)\n`,i2c <amount>$` (e.g. `,i2c 10$`)"
      );
      return msg.reply({ embeds: [errEmbed] });
    }

    let sign = 'INR';
    let amountStr = input;
    if (input.endsWith('$')) {
      sign = 'USD';
      amountStr = input.slice(0, -1);
    }
    
    const amount = parseFloat(amountStr);
    // --- ERROR EMOJI: Not changing this error embed per user request ---
    if (isNaN(amount)) {
      const errEmbed = new EmbedBuilder().setColor(0xe74c3c).setTitle("❌ Invalid Amount")
        .setDescription("Please provide a valid number.\n**Usage:**\n`,i2c 945`\n`,i2c 10$`");
      return msg.reply({ embeds: [errEmbed] });
    }

    // --- Calculations ---
    if (sign === 'USD') {
      const amount_usd = amount;
      const amount_inr = amount_usd * I2C_RATE;

      const embed = new EmbedBuilder()
        .setTitle(`${emojis.exchange} INR TO CRYPTO`) // <-- EMOJI
        .setColor(0x731b15) 
        .addFields(
          { name: "He Will Pay:", value: `₹${amount_inr.toFixed(2)}` },
          { name: "__He Will Receive__:", value: `$${amount_usd.toFixed(2)}` }
        )
        .setFooter({ text: `I2C Rate: ${I2C_RATE} INR/$` });
      
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`calc_i2c_mul_${amount_usd}`)
          .setLabel("Calculation")
          .setStyle(ButtonStyle.Primary) 
      );
      
      return msg.reply({ embeds: [embed], components: [row] }); 

    } else {
      const amount_inr = amount;
      const amount_usd = amount_inr / I2C_RATE;

      const embed = new EmbedBuilder()
        .setTitle(`${emojis.exchange} INR TO CRYPTO`) // <-- EMOJI
        .setColor(0x731b15) 
        .addFields(
          { name: "He will Pay:", value: `₹${amount_inr.toFixed(2)}` },
          { name: "__He Will Recieve__:", value: `$${amount_usd.toFixed(2)}` }
        )
        .setFooter({ text: `I2C Rate: ${I2C_RATE} INR/$` });
      
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`calc_i2c_div_${amount_inr}`)
          .setLabel("Calculation")
          .setStyle(ButtonStyle.Primary) 
      );
      
      return msg.reply({ embeds: [embed], components: [row] }); 
    }
  }

  // ===== NEW C2I COMMAND =====
  if (command === "c2i") {
    const input = args[0];

    // --- ERROR EMOJI: Not changing this error embed per user request ---
    if (!input) {
      const errEmbed = new EmbedBuilder().setColor(0xe74c3c).setTitle("❌ Missing Amount")
        .setDescription("Please provide an amount.\n**Usage:**\n`,c2i <amount>` (e.g. `,c2i 905`)\n`,c2i <amount>$` (e.g. `,c2i 10$`)"
      );
      return msg.reply({ embeds: [errEmbed] });
    }

    let sign = 'INR';
    let amountStr = input;
    if (input.endsWith('$')) {
      sign = 'USD';
      amountStr = input.slice(0, -1);
    }
    
    const amount = parseFloat(amountStr);
    // --- ERROR EMOJI: Not changing this error embed per user request ---
    if (isNaN(amount)) {
      const errEmbed = new EmbedBuilder().setColor(0xe74c3c).setTitle("❌ Invalid Amount")
        .setDescription("Please provide a valid number.\n**Usage:**\n`,c2i 905`\n`,c2i 10$`");
      return msg.reply({ embeds: [errEmbed] });
    }

    // --- Calculations ---
    if (sign === 'USD') {
      const amount_usd = amount;
      const amount_inr = amount_usd * C2I_RATE;

      const embed = new EmbedBuilder()
        .setTitle(`${emojis.dollars} CRYPTO TO INR`) // <-- EMOJI
        .setColor(0x501c67) 
        .addFields(
          { name: "__He Have To Pay__:", value: `$${amount_usd.toFixed(2)}` },
          { name: "He Will Receive:", value: `₹${amount_inr.toFixed(2)}` }
        )
        .setFooter({ text: `C2I Rate: ${C2I_RATE} INR/$` });
      
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`calc_c2i_mul_${amount_usd}`)
          .setLabel("Calculation")
          .setStyle(ButtonStyle.Primary) 
      );
      
      return msg.reply({ embeds: [embed], components: [row] }); 

    } else {
      const amount_inr = amount;
      const amount_usd = amount_inr / C2I_RATE;

      const embed = new EmbedBuilder()
        .setTitle(`${emojis.dollars} CRYPTO TO INR`) // <-- EMOJI
        .setColor(0x501c67) 
        .addFields(
          { name: "__He Will Receive__:", value: `₹${amount_inr.toFixed(2)}` },
          { name: "He Have To Pay:", value: `$${amount_usd.toFixed(2)}` }
        )
        .setFooter({ text: `C2I Rate: ${C2I_RATE} INR/$` });
      
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`calc_c2i_div_${amount_inr}`)
          .setLabel("Calculation")
          .setStyle(ButtonStyle.Primary) 
      );

      return msg.reply({ embeds: [embed], components: [row] }); 
    }
  }

});

// --- INTERACTION HANDLERS ---
client.on("interactionCreate", async (interaction) => {
  
  // --- NEW: HELP MENU HANDLER (COOLER REPLY) ---
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId === "help_menu") {
      try {
        const commandKey = interaction.values[0]; // e.g., "setaddy"
        const cmdInfo = commandsInfo[commandKey];

        if (!cmdInfo) {
          return interaction.reply({ content: `${emojis.invalid_alert} Error: Could not find details for that command.`, ephemeral: true });
        }
        
        // --- NEW: Better formatted ephemeral reply ---
        const commandEmbed = new EmbedBuilder()
          .setTitle(`${cmdInfo.emoji} Command: ${cmdInfo.usage.split(' ')[0]}`) 
          .setColor(0x3498db)
          .setDescription(`**Usage:** \`\`\`${cmdInfo.usage}\`\`\` \n**Description:**\n${cmdInfo.description}`);
          
        await interaction.reply({ embeds: [commandEmbed], ephemeral: true });
        
      } catch (e) {
        console.error("Failed to handle help menu selection:", e);
        try {
            await interaction.reply({ content: `${emojis.invalid_alert} An error occurred while fetching command details.`, ephemeral: true });
        } catch (err) {}
      }
    }
    return; // Stop processing
  }
  
  // --- BUTTON HANDLERS ---
  if (interaction.isButton()) {
    
    // --- NEW QR BUTTON HANDLER ---
    if (interaction.customId.startsWith("gen_qr_")) {
      try {
        await interaction.deferUpdate(); // Acknowledge the interaction
        const parts = interaction.customId.split('_');
        const upiName = parts[2];
        const amount = parts[3]; // This will be '0' if no amount

        const userUpis = upiAddresses[interaction.user.id];
        if (!userUpis || !userUpis[upiName]) {
          return interaction.followUp({ content: `${emojis.invalid_alert} Error: Could not find that UPI ID. It might have been deleted.`, ephemeral: true });
        }

        const upi = userUpis[upiName];
        const paynote = "I AUTHORISE THIS PAYMENT";
        
        let upiLink;
        if (amount === '0' || isNaN(amount)) {
          upiLink = `upi://pay?pa=${upi}&pn=Payment&tn=${encodeURIComponent(paynote)}`;
        } else {
          upiLink = `upi://pay?pa=${upi}&am=${amount}&pn=Payment&tn=${encodeURIComponent(paynote)}`;
        }

        const qrBuffer = await QRCode.toBuffer(upiLink);
        
        const embed = new EmbedBuilder()
          .setTitle("UPI Payment QR")
          .setColor(0x8B0000) // Maroon
          .setImage("attachment://qr.png");
          
        const amountText = (amount === '0' || isNaN(amount)) ? 'No amount specified' : `₹${amount}`;
        const qrDescription = `\`\`\`\nAmount: ${amountText}\nPayment Note: ${paynote}\n\`\`\``;
        embed.setDescription(qrDescription);

        const row = new ActionRowBuilder();
        
        const noteButton = new ButtonBuilder()
          .setCustomId('show_payment_note')
          .setLabel('Payment Note')
          .setStyle(ButtonStyle.Primary) // Blue
          .setEmoji(getEmojiId(emojis.paynote)) // <-- EMOJI
          .setDisabled(false); // Enabled
          
        const backButton = new ButtonBuilder()
          .setCustomId(`back_to_upi_select_${amount}`)
          .setLabel('Back')
          .setStyle(ButtonStyle.Primary) // Blue
          .setEmoji(getEmojiId(emojis.back_arrow_animated)); // <-- EMOJI
          
        row.addComponents(noteButton, backButton);
        
        await interaction.editReply({ embeds: [embed], files: [{ attachment: qrBuffer, name: "qr.png" }], components: [row] });
      } catch (e) {
        console.error("Failed to generate QR:", e);
        try {
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: `${emojis.invalid_alert} An error occurred while generating the QR code.`, ephemeral: true });
          } else {
            await interaction.followUp({ content: `${emojis.invalid_alert} An error occurred while generating the QR code.`, ephemeral: true });
          }
        } catch (err) {
            console.error("Failed to send QR error:", err);
        }
      }
      return; // Stop processing
    }
    
    // --- NEW: PAYMENT NOTE BUTTON HANDLER ---
    if (interaction.customId === "show_payment_note") {
        try {
            const paynote = "I AUTHORISE THIS PAYMENT";
            await interaction.reply({ content: paynote, ephemeral: true });
        } catch (e) {
            console.error("Failed to send payment note:", e);
        }
        return; // Stop processing
    }

    // --- NEW BACK BUTTON HANDLER ---
    if (interaction.customId.startsWith("back_to_upi_select_")) {
      try {
        await interaction.deferUpdate(); // Acknowledge the interaction
        const amountString = interaction.customId.split('_')[4];
        const userUpis = upiAddresses[interaction.user.id];

        if (!userUpis || Object.keys(userUpis).length === 0) {
          return interaction.editReply({ content: `${emojis.invalid_alert} You have no UPI IDs saved.`, embeds: [], components: [], files: [] });
        }
        
        const selectionPayload = buildUpiSelection(userUpis, amountString);
        await interaction.editReply(selectionPayload); // Update back to selection screen
      } catch (e) {
          console.error("Failed to go back to UPI select:", e);
           try {
              if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: `${emojis.invalid_alert} An error occurred.`, ephemeral: true });
              } else {
                await interaction.followUp({ content: `${emojis.invalid_alert} An error occurred.`, ephemeral: true });
              }
           } catch (err) {
               console.error("Failed to send back error:", err);
           }
      }
      return; // Stop processing
    }

    // --- NEW CALCULATION BUTTON HANDLER ---
    if (interaction.customId.startsWith("calc_")) {
      try {
        const parts = interaction.customId.split('_');
        const type = parts[1]; // 'i2c'
        const op = parts[2]; // 'div'
        const amount = parts[3]; // '945'

        let calcString = "";
        if (type === 'i2c') {
          calcString = (op === 'div') 
            ? `.calc ${amount}/${I2C_RATE}` 
            : `.calc ${amount}*${IZ_RATE}`;
        } else { // 'c2i'
          calcString = (op === 'div')
            ? `.calc ${amount}/${C2I_RATE}`
            : `.calc ${amount}*${C2I_RATE}`;
        }

        await interaction.channel.send(calcString);
        await interaction.deferUpdate();
        return; 

      } catch (e) {
        console.error("Failed to handle calc button:", e);
        try {
          if (!interaction.deferred && !interaction.replied) {
            await interaction.reply({ content: `${emojis.invalid_alert} An error occurred.`, ephemeral: true });
          }
        } catch (err) {
          console.error("Failed to send ephemeral error:", err);
        }
      }
    }

    // --- Existing Button Handlers ---
    if (interaction.customId === "showaddy") {
      const addr = addresses[interaction.user.id];
      const content = addr ? addr : `${emojis.invalid_alert} You haven't set an address.`;
      return interaction.reply({ content, ephemeral: true });
    }

    if (interaction.customId === "showupi") {
      const userUpis = upiAddresses[interaction.user.id];
      let content = `${emojis.invalid_alert} No UPI IDs saved.`;
      if (userUpis && Object.keys(userUpis).length > 0) {
        content = Object.entries(userUpis).map(([n, i]) => `${n === "default" ? emojis.star_maroon : ""}**${n}** → \`${i}\``).join("\n"); // <-- EMOJI
      }
      return interaction.reply({ content, ephemeral: true });
    }
  }
});

client.login(TOKEN);